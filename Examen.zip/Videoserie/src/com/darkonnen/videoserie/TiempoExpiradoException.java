package com.darkonnen.videoserie;

public class TiempoExpiradoException {
	
	public void multa() {
		System.out.println("Te has retrasado en la devolución, hay multa");
	}

}
