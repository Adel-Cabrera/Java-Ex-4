package com.darkonnen.videoserie;

public abstract class VideoSerie {
	
	public abstract void verresumen(); // retorna un resumen de los atributos del objeto que la implementa.

}
